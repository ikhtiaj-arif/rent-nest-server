# RentNest Backend — Complete Implementation Roadmap
**54-Hour Execution Plan | Target: 60 Marks (July 09, 2026 deadline)**

---

## 1. Requirement Extraction Summary

### 1.1 The Six Mandatory Requirements (any missing = 0 marks)
| # | Requirement | Non-Negotiable Detail |
|---|---|---|
| 1 | API Documentation | Postman collection OR Swagger/OpenAPI, must cover **every** endpoint |
| 2 | Consistent Error Format | Every error → `{ success: false, message, errorDetails }` |
| 3 | Commits | 20+ meaningful backend commits, descriptive messages |
| 4 | Input Validation | Server-side validation on **all** endpoints, clear error messages |
| 5 | Admin Credentials | A real, working admin login must exist in production |
| 6 | Real Payment Integration | Stripe or SSLCommerz only — no COD/fake/"pay later" simulation |

### 1.2 Marks Map (put your hours where the marks are)
| Category | Weight | Roadmap Phase(s) that earn it |
|---|---|---|
| API Design & Docs | 20% | Phase 2–7 (build) + Phase 8 (docs) |
| Database Design | 20% | Phase 1 |
| Commit History | 10% | Ongoing, every phase |
| Error Handling & Validation | 10% | Phase 2–7, hardened in Phase 8 |
| Core Functionality (auth/CRUD/RBAC) | 20% | Phase 2–5 |
| Payment Integration | 10% | Phase 6 |
| Video Walkthrough | 10% | Phase 9 |

**Reading this table correctly:** DB design + API/docs + core functionality = 60% of marks and are also the riskiest to get wrong under time pressure — they get first claim on your best hours (see §7).

### 1.3 Roles (fixed, exactly 3)
- **Tenant** — browse, request rental, pay, review, manage own profile
- **Landlord** — CRUD own properties, approve/reject requests on own properties, view own tenant history
- **Admin** — view/manage all users (ban/unban), view all listings & rentals, manage categories

### 1.4 Explicit Entities
Users, Properties, Categories, RentalRequests, Payments, Reviews

### 1.5 Implicit Entities You Must Add (not named but required by features)
- **RefreshToken / Session** (optional, only if you implement refresh tokens — otherwise skip, JWT access token alone is acceptable)
- Nothing else is strictly required — resist scope creep. Do NOT add Wallets, Notifications, Messaging, or Favorites unless you finish everything else with time to spare (Optional/Nice-to-have only).

### 1.6 Hidden/Implicit Business Rules Buried in the Flow Diagrams
The flow diagrams encode a **state machine** that the README text doesn't spell out directly:
- RentalRequest status: `PENDING → APPROVED/REJECTED → (if APPROVED) PAYMENT → ACTIVE → COMPLETED`
- Reviews can only happen after `COMPLETED`, not just after `APPROVED`
- Payment can only be created for a request that is `APPROVED` (not pending/rejected)
- The diagram implies **Payments and RentalRequests are 1:1 per successful transaction**, but a request could have multiple *failed* payment attempts before one succeeds — your schema must allow multiple Payment rows per RentalRequest, with only one ultimately `completed`.

### 1.7 Technical Risks / Things That Silently Cost Marks
| Risk | Why it costs marks | Mitigation |
|---|---|---|
| Fake/simulated payment | Instant 0 on Payment Integration (10%) and possibly flagged as violating mandatory rules | Use Stripe test mode or SSLCommerz sandbox — real API calls, real webhook/callback handling |
| Inconsistent error shape | Docked under Error Handling (10%) | Build a central error handler + `ApiError` class in Phase 1, use everywhere from day one |
| Missing role checks on landlord/admin routes | Docked under Core Functionality (20%) | Central `requireRole()` middleware, applied at router level, tested per route |
| No 404 handling for unknown routes/resources | Explicitly named in grading rubric | Global 404 handler + per-resource "not found" checks |
| Squashing all work into 1-2 commits at the end | Instant loss on Commit History (10%) and looks like plagiarism/rushed work | Commit after every completed task, not every completed phase |
| Postman docs written after the fact and incomplete | 20% category partially lost | Build the Postman collection incrementally as each route is finished, not at the end |
| No seed data / empty DB on submission | Reviewer can't test anything → cascading marks loss across categories | Seed script with 1 admin, 2+ landlords, 2+ tenants, categories, a few properties, one full request→payment→review cycle |
| Duplicate reviews / duplicate pending requests not prevented | Business logic marks lost, "Core Functionality" | Unique constraints + explicit checks (see Business Rules §3) |
| Deployment breaks env vars (DB URL, JWT secret, Stripe keys) | "Live API URL" requirement fails entirely | `.env.example` committed, documented in README, tested on a clean clone before final submission |

---

## 2. Database Planning (no code — pure design)

### 2.1 Models & Key Fields

**User**
- id, name, email (unique), password (hashed), role (enum: TENANT/LANDLORD/ADMIN), status (enum: ACTIVE/BANNED), phone (optional), createdAt, updatedAt

**Category**
- id, name (unique), description (optional)

**Property**
- id, landlordId (FK → User), categoryId (FK → Category), title, description, address, city, price, bedrooms, bathrooms, amenities (string array or JSON), isAvailable (boolean), images (string array), createdAt, updatedAt

**RentalRequest**
- id, tenantId (FK → User), propertyId (FK → Property), status (enum: PENDING/APPROVED/REJECTED/ACTIVE/COMPLETED/CANCELLED), moveInDate, message (optional), createdAt, updatedAt

**Payment**
- id, rentalRequestId (FK → RentalRequest), amount, method/provider (enum: STRIPE/SSLCOMMERZ), status (enum: PENDING/COMPLETED/FAILED), transactionId (unique, nullable until confirmed), paidAt (nullable), createdAt

**Review**
- id, tenantId (FK → User), propertyId (FK → Property), rentalRequestId (FK → RentalRequest), rating (int 1–5), comment, createdAt

### 2.2 Relationships
- User (1) —— (M) Property [as landlord]
- User (1) —— (M) RentalRequest [as tenant]
- Property (1) —— (M) RentalRequest
- Category (1) —— (M) Property
- RentalRequest (1) —— (M) Payment (only one should end up COMPLETED)
- RentalRequest (1) —— (1) Review (optional — a request produces at most one review)
- User (1) —— (M) Review [as tenant]
- Property (1) —— (M) Review

### 2.3 Enums
- `Role`: TENANT, LANDLORD, ADMIN
- `UserStatus`: ACTIVE, BANNED
- `RentalStatus`: PENDING, APPROVED, REJECTED, ACTIVE, COMPLETED, CANCELLED
- `PaymentProvider`: STRIPE, SSLCOMMERZ
- `PaymentStatus`: PENDING, COMPLETED, FAILED

### 2.4 Constraints & Indexes
- `User.email` — unique index
- `Category.name` — unique index
- `Payment.transactionId` — unique index (nullable-safe unique)
- Composite unique on `(tenantId, propertyId, status)` where status = PENDING is not directly expressible in a plain unique constraint — enforce **duplicate pending request prevention at the application layer** (query check before insert) rather than at DB level, OR use a partial unique index if your Postgres setup supports it
- Unique on `(tenantId, propertyId, rentalRequestId)` for Review to prevent duplicate reviews per completed rental
- Index on `Property.city`, `Property.price`, `Property.categoryId` — these are your filter/search fields, so they need indexes for query performance and to visibly demonstrate DB design maturity
- Foreign keys: cascade delete is **not** appropriate here (you don't want a deleted property wiping out payment history) — prefer `onDelete: Restrict` or soft-deletes (`isAvailable=false` / `status=BANNED` instead of hard deletes) for Users and Properties

---

## 3. Business Rules (explicit + implicit)

**Authentication & Roles**
- Role is fixed at registration; do not allow changing role after signup
- Banned users cannot log in or access any protected route (check `status` in auth middleware, not just JWT validity)

**Properties**
- Only the owning landlord can update/delete their property
- Admin can view all properties but per README does not directly edit landlord listings (view/moderate only, unless you extend — keep to spec)
- A property must belong to a valid category

**Rental Requests**
- A tenant cannot submit a rental request for their own property (n/a since tenants don't own properties, but validate role at the endpoint anyway)
- Prevent duplicate **pending** rental requests from the same tenant for the same property
- Only the landlord who owns the property can approve/reject a request for it
- A request can only move PENDING → APPROVED or PENDING → REJECTED (no other transitions allowed from PENDING)
- Tenant cannot pay before the request is APPROVED
- Once APPROVED and paid, request moves to ACTIVE, then eventually COMPLETED (you decide the trigger for COMPLETED — e.g., admin/landlord action or move-out date; document your choice)

**Payments**
- Payment must reference an APPROVED rental request
- A rental request cannot have two COMPLETED payments
- Failed payments should not block retrying (allow a new Payment row on retry)
- Payment amount must match the property's price (or your defined rent calculation) — validate server-side, never trust client-submitted amount

**Reviews**
- Reviews only allowed after the rental request reaches COMPLETED status
- Prevent duplicate reviews for the same rental request
- A tenant can only review a property they actually rented (validated via RentalRequest ownership)

**Admin**
- Only admin can ban/unban users
- Banned users cannot create requests, properties, payments, or reviews
- Only admin can manage categories (create/edit/delete)

---

## 4. API Planning

> Auth column: 🔓 Public · 🔑 Any authenticated user · 🔒 Role-restricted

### Auth
| Method | Route | Auth | Roles | Purpose |
|---|---|---|---|---|
| POST | /api/auth/register | 🔓 | — | Register (tenant/landlord); admin created via seed only |
| POST | /api/auth/login | 🔓 | — | Login, returns JWT |
| GET | /api/auth/me | 🔑 | any | Current user profile |
| PUT | /api/auth/me | 🔑 | any | Update own profile |

### Properties (Public + Landlord)
| Method | Route | Auth | Roles | Purpose |
|---|---|---|---|---|
| GET | /api/properties | 🔓 | — | List with filters: location, price range, type, amenities |
| GET | /api/properties/:id | 🔓 | — | Property details |
| GET | /api/categories | 🔓 | — | List categories |
| POST | /api/landlord/properties | 🔒 | LANDLORD | Create listing |
| PUT | /api/landlord/properties/:id | 🔒 | LANDLORD (owner) | Update listing |
| DELETE | /api/landlord/properties/:id | 🔒 | LANDLORD (owner) | Remove listing |
| PATCH | /api/landlord/properties/:id/availability | 🔒 | LANDLORD (owner) | Toggle availability |

### Rental Requests
| Method | Route | Auth | Roles | Purpose |
|---|---|---|---|---|
| POST | /api/rentals | 🔒 | TENANT | Submit request |
| GET | /api/rentals | 🔑 | any | Own requests (tenant) or received (landlord scoped separately below) |
| GET | /api/rentals/:id | 🔑 | owner/landlord/admin | Request details |
| GET | /api/landlord/requests | 🔒 | LANDLORD | Requests on own properties |
| PATCH | /api/landlord/requests/:id | 🔒 | LANDLORD (owner) | Approve/reject |

### Payments
| Method | Route | Auth | Roles | Purpose |
|---|---|---|---|---|
| POST | /api/payments/create | 🔒 | TENANT | Create payment intent/session for approved rental |
| POST | /api/payments/confirm | 🔓 (webhook) or 🔑 | — | Confirm/verify payment (webhook or callback endpoint) |
| GET | /api/payments | 🔑 | any | Own payment history |
| GET | /api/payments/:id | 🔑 | owner/admin | Payment details |

### Reviews
| Method | Route | Auth | Roles | Purpose |
|---|---|---|---|---|
| POST | /api/reviews | 🔒 | TENANT | Create review after COMPLETED rental |
| GET | /api/properties/:id/reviews | 🔓 | — | Public reviews for a property (not in original list but needed to display reviews — add it) |

### Admin
| Method | Route | Auth | Roles | Purpose |
|---|---|---|---|---|
| GET | /api/admin/users | 🔒 | ADMIN | All users |
| PATCH | /api/admin/users/:id | 🔒 | ADMIN | Ban/unban |
| GET | /api/admin/properties | 🔒 | ADMIN | All properties |
| GET | /api/admin/rentals | 🔒 | ADMIN | All rental requests |
| POST | /api/admin/categories | 🔒 | ADMIN | Create category |
| PUT | /api/admin/categories/:id | 🔒 | ADMIN | Edit category |
| DELETE | /api/admin/categories/:id | 🔒 | ADMIN | Delete category |

---

## 5. Implementation Order (and why)

```
1. Project Setup & DB Schema
2. Authentication (register/login/JWT)
3. Authorization (role middleware)
4. Core Entities (Categories, Properties)
5. Business Logic (Rental Requests + state machine)
6. Payments (Stripe/SSLCommerz)
7. Reviews
8. Admin Module
9. Validation & Error Handling Hardening (pass over everything)
10. API Documentation (Postman/Swagger)
11. Seed Data & Deployment
12. Video & Final Submission
```

**Why this order:**
- **DB first** — everything else depends on the schema; changing it later cascades into every controller.
- **Auth before anything else** — every other feature is gated behind "who is this user," so it must exist before you can even test role-based routes.
- **Authorization right after auth** — role checks are cheap middleware but touch every route; build the middleware once, early, and apply it consistently rather than retrofitting.
- **Core entities (Properties/Categories) before business logic** — Rental Requests reference Properties, so Properties must exist and be CRUD-complete first.
- **Rental Requests before Payments** — Payments are contractually dependent on an APPROVED request; you cannot meaningfully test payment code without the state machine working.
- **Payments before Reviews** — Reviews are gated on COMPLETED rentals, which only exist after payment logic works.
- **Admin last among features** — Admin mostly reads/moderates data produced by the other modules, so it's most efficiently built once those exist (you can test admin ban logic against real seeded users/properties).
- **Validation/error-handling pass is explicitly separate** — bolting it on per-route as you go is fine, but a dedicated hardening pass catches gaps (missing 404s, inconsistent shapes) before docs are written.
- **Docs after code, not before** — writing Postman docs against a moving API wastes time; docs come once endpoints are stable, but you should scaffold the collection incrementally (see Task Checklist).
- **Deployment before the video** — you need a live URL to demo confidently; recording against localhost and hoping deployment "just works" later is a common last-minute disaster.

---

## 6. Detailed Task Checklist

### Phase 0 — Project Setup
- [ ] Init Node + TypeScript + Express project
- [ ] Install Prisma, configure PostgreSQL connection
- [ ] Set up folder structure (routes/controllers/services/middleware/utils)
- [ ] Configure `.env` + `.env.example`
- [ ] Set up centralized `ApiError` class and `success/message/errorDetails` response helper
- [ ] Global error-handling middleware
- [ ] Global 404 handler
- [ ] ESLint/Prettier (optional but fast credibility win)
- [ ] Git init, first commit

### Phase 1 — Database Schema
- [ ] Write Prisma schema: User, Category, Property, RentalRequest, Payment, Review
- [ ] Add enums (Role, UserStatus, RentalStatus, PaymentProvider, PaymentStatus)
- [ ] Add relationships & foreign keys
- [ ] Add unique constraints & indexes (§2.4)
- [ ] Run first migration
- [ ] Commit: "db: initial schema with core models"

### Phase 2 — Authentication
- [ ] User model already exists (from schema)
- [ ] Register endpoint (role selection, password hashing via bcrypt)
- [ ] Login endpoint (JWT generation)
- [ ] Auth middleware (verify JWT, attach `req.user`, reject if BANNED)
- [ ] `GET /auth/me`, `PUT /auth/me`
- [ ] Input validation (zod/joi) on register/login
- [ ] Error cases: duplicate email, wrong password, banned user login attempt
- [ ] Commit per sub-feature (register, login, me, validation)

### Phase 3 — Authorization
- [ ] `requireRole(...roles)` middleware
- [ ] Apply to landlord/admin routers
- [ ] Ownership-check helper (e.g., `isResourceOwner`) for property/request updates
- [ ] Commit: "feat: role-based access control middleware"

### Phase 4 — Categories & Properties
- [ ] Category CRUD (admin-only writes, public read)
- [ ] Property create/update/delete (landlord, ownership-checked)
- [ ] Property list with filters (location, price range, type, amenities) + pagination
- [ ] Property details endpoint
- [ ] Availability toggle
- [ ] Validation on all property fields
- [ ] Commits: category CRUD, property CRUD, property filters/search

### Phase 5 — Rental Requests
- [ ] Create request (tenant) — block duplicate pending requests
- [ ] List own requests (tenant)
- [ ] Landlord: list requests for own properties
- [ ] Landlord: approve/reject (status transition guard: only from PENDING)
- [ ] Request details endpoint (owner/landlord/admin only)
- [ ] Validation + error cases (property not found, already requested, not owner)
- [ ] Commits: create request, list/detail, approve/reject logic

### Phase 6 — Payments (Stripe or SSLCommerz — pick ONE)
- [ ] Choose provider, set up sandbox/test account & API keys
- [ ] `POST /payments/create` — validate request is APPROVED, create intent/session, store PENDING Payment row
- [ ] `POST /payments/confirm` — webhook/callback handler, verify signature, update Payment→COMPLETED, RentalRequest→ACTIVE
- [ ] Handle failed payment path (Payment→FAILED, allow retry)
- [ ] `GET /payments`, `GET /payments/:id`
- [ ] Validation + error handling (double payment, unapproved request, amount mismatch)
- [ ] Manually test full payment flow end-to-end in sandbox
- [ ] Commits: payment creation, webhook/confirm handling, payment history endpoints

### Phase 7 — Reviews
- [ ] Create review — validate rentalRequest is COMPLETED and belongs to tenant
- [ ] Prevent duplicate review per rental request
- [ ] Public: list reviews per property
- [ ] Commit: "feat: review system with completion + duplicate guards"

### Phase 8 — Admin
- [ ] List all users, ban/unban (block login/actions when banned)
- [ ] List all properties, all rentals (read-only per spec)
- [ ] Category management endpoints (if not already built in Phase 4)
- [ ] Commit: "feat: admin moderation endpoints"

### Phase 9 — Hardening Pass
- [ ] Re-check every endpoint returns `{ success, message, errorDetails }` on error
- [ ] Re-check every endpoint validates input server-side
- [ ] Re-check every protected route has correct role + ownership checks
- [ ] Add rate-limiting/helmet/cors basics (quick wins, low effort)
- [ ] Commit: "fix: standardize error responses and validation across all routes"

### Phase 10 — Seed Data
- [ ] Seed script: 1 admin, 2 landlords, 2 tenants, 3–4 categories, 4–6 properties
- [ ] Seed one full lifecycle: request → approved → paid (COMPLETED) → reviewed
- [ ] Seed one PENDING and one REJECTED request for demo variety
- [ ] Commit: "chore: add seed script with demo data"

### Phase 11 — API Documentation
- [ ] Build Postman collection (or Swagger) incrementally — don't leave to the very end
- [ ] Document auth requirement + roles per endpoint
- [ ] Include example request/response bodies, including error examples
- [ ] Export/publish collection, get shareable link
- [ ] Commit: "docs: complete Postman collection for all endpoints"

### Phase 12 — Deployment
- [ ] Deploy DB (e.g., Neon/Supabase/Railway Postgres)
- [ ] Deploy API (Vercel/Render)
- [ ] Set all env vars in production (DB URL, JWT secret, Stripe/SSLCommerz keys)
- [ ] Run migrations + seed against production DB
- [ ] Smoke-test every route against the live URL
- [ ] Commit: "chore: deployment config"

### Phase 13 — README & Video
- [ ] Write README: setup instructions, tech stack, admin credentials, API docs link, live URL
- [ ] Record 3–5 min demo video (all 3 roles, CRUD, error handling, one technical challenge explained)
- [ ] Upload video, set sharing permissions
- [ ] Final commit: "docs: final README and submission info"

---

## 7. Time Management (54 Hours Total)

**Principle:** Marks-weighted categories (DB 20%, API/Docs 20%, Core Functionality 20% = 60% combined) must be **done and correct**, not just started, before you spend time polishing anything. Payment (10%) is mandatory-pass/fail — treat it as equally urgent despite lower weight because a fake/broken integration can zero out the category entirely.

### First 6 Hours — Foundation (must not slip)
- Project setup, Prisma schema fully modeled (§Phase 0–1)
- Auth: register/login/JWT/me working with validation
- **Checkpoint:** you can register 3 roles and log in as each

### Hours 6–12 — Authorization + Core Entities
- Role middleware + ownership checks
- Categories CRUD + Properties CRUD (landlord side) + public property listing/filtering
- **Checkpoint:** landlord can create a property; public can list/filter it

### Hours 12–24 — Business Logic Core
- Rental Requests: create, list, approve/reject, all state-transition guards
- Start Payments: pick provider, get sandbox keys working, build `/payments/create`
- **Checkpoint:** full flow request→approve reachable via Postman manually

### Hours 24–36 — Payments Complete + Reviews + Admin
- Finish payment confirm/webhook flow end-to-end (this is the highest-risk technical piece — do not leave it late)
- Reviews module
- Admin module
- **Checkpoint:** one full lifecycle (request→pay→complete→review) works manually end-to-end

### Hours 36–42 — Hardening
- Validation/error-response consistency pass across all routes
- 404 handling, edge cases from Business Rules (§3)
- **Checkpoint:** deliberately hit 5–10 error scenarios per module and confirm consistent JSON shape

### Hours 42–48 — Seed + Docs + Deployment
- Seed script
- Postman collection finalized and published
- Deploy DB + API, set env vars, run migration+seed in production
- **Checkpoint:** live URL responds correctly to a fresh Postman run against production

### Hours 48–52 — README + Video
- Final README with all required links/credentials
- Record and upload demo video

### Hours 52–54 — Buffer
- Reserved for: deployment issues, Stripe/SSLCommerz sandbox quirks, last bug fixes, re-recording video if needed
- **Do not schedule new features here.**

### If You Are Running Out of Time — Cut in This Order (least to most costly)
1. Property filters beyond basic (keep location + price only, drop amenities filter)
2. Swagger polish — a clean, complete Postman collection is enough, don't build both
3. Admin category management UI-equivalent richness — keep it to bare CRUD
4. Refresh tokens / advanced auth — plain JWT access token is sufficient
5. **Never cut:** payment integration authenticity, error response consistency, validation, admin credentials, 20 commits, seed data — these map directly to mandatory/high-weight items.

---

## 8. Git Commit Plan (20–30 commits, in order)

1. `chore: initial project setup with TypeScript and Express`
2. `chore: configure Prisma and PostgreSQL connection`
3. `feat: define database schema for all core models`
4. `chore: run initial migration`
5. `feat: centralized error handler and response format`
6. `feat: user registration with role selection`
7. `feat: login endpoint with JWT generation`
8. `feat: auth middleware and current-user endpoint`
9. `feat: input validation for auth routes`
10. `feat: role-based access control middleware`
11. `feat: category CRUD endpoints`
12. `feat: property creation and update (landlord)`
13. `feat: property listing with filters and pagination`
14. `feat: property details and availability toggle`
15. `feat: rental request creation with duplicate-prevention`
16. `feat: rental request listing and detail endpoints`
17. `feat: landlord approve/reject rental request logic`
18. `feat: payment session/intent creation`
19. `feat: payment confirmation webhook and status update`
20. `feat: payment history endpoints`
21. `feat: review creation with completion and duplicate guards`
22. `feat: public reviews listing per property`
23. `feat: admin user management (ban/unban)`
24. `feat: admin read-only property and rental oversight`
25. `fix: standardize validation and error responses across all routes`
26. `chore: seed script with demo users, properties, and full rental lifecycle`
27. `docs: complete Postman collection for all endpoints`
28. `chore: production deployment configuration`
29. `docs: final README with setup, credentials, and submission links`
30. `chore: final fixes after end-to-end production testing`

---

## 9. Final Submission Checklist

**Mandatory Requirements**
- [ ] API docs (Postman/Swagger) cover every single endpoint
- [ ] Every error response follows `{ success, message, errorDetails }`
- [ ] 20+ meaningful commits, descriptive messages, spread across development (not batched at the end)
- [ ] Server-side validation on every endpoint
- [ ] Working admin email/password on the deployed instance
- [ ] Real Stripe or SSLCommerz integration (sandbox/test mode is fine, simulation is not)

**Functional Completeness**
- [ ] All 3 roles can register/login
- [ ] Full tenant journey works: browse → request → wait → pay → review
- [ ] Full landlord journey works: create listing → view requests → approve/reject
- [ ] Admin can ban/unban, view all users/properties/rentals, manage categories
- [ ] Banned users are blocked from all protected actions
- [ ] Rental state machine transitions are enforced, not just implied

**Data & Environment**
- [ ] Seed script produces a realistic, testable dataset
- [ ] `.env.example` committed with all required variable names (no real secrets)
- [ ] Production environment variables correctly set
- [ ] Migrations applied cleanly on a fresh database

**Docs & Submission Package**
- [ ] Backend GitHub repo — public or accessible to reviewer
- [ ] Live API URL — smoke-tested right before submission
- [ ] API documentation link
- [ ] Demo video (3–5 min) — link permissioned correctly ("anyone with link")
- [ ] Admin credentials clearly listed
- [ ] README includes setup instructions, tech stack, all above links

**Last-Minute Sanity Checks**
- [ ] Test the entire flow against the **live** URL, not just localhost, right before submitting
- [ ] Confirm the demo video plays back correctly from the shared link on a different device/account
- [ ] Confirm admin login works on the deployed instance specifically
