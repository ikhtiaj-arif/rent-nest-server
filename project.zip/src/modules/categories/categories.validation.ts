// Categories Validation schema placeholder
