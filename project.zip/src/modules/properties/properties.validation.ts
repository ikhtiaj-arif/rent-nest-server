// Properties Validation schema placeholder
